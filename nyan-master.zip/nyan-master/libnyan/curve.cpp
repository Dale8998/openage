// Copyright 2017-2017 the nyan authors, LGPLv3+. See copying.md for legal info.

#include "curve.h"


namespace nyan {

} // namespace nyan
