// Copyright 2016-2017 the nyan authors, LGPLv3+. See copying.md for legal info.

#include "set_base.h"


namespace nyan {

} // namespace nyan
