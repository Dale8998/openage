nyan
====

[language specification](./nyan.md)
