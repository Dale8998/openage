Internet
========

Even though the internet is probably just a passing fad that
will fade back into obscurity once the general public
moves on to something else, contact may permanently
contaminate your device with its many dangers:
infective or allergenic cyber software,
cyber rape, and cyber terrorism.

These stickers will warn innocent bystanders not to go
near your device or even use it without taking the necessary
precautions. [Because safety counts!](../sicher)


### Printing

size: 105 × 35 mm
3mm bleed on each side additional to the size.


### License

These stickers are licensed under public domain CC0 "No rights reserved".

[![CC0](http://i.creativecommons.org/p/zero/1.0/88x31.png)](http://creativecommons.org/publicdomain/zero/1.0/)

