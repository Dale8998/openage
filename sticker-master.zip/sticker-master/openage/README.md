openage
=======

This is a promotional sticker for [openage](https://github.com/SFTtech/openage).


### Printing

size: 148 × 35 mm
3mm bleed included on each side, which is why the file is bigger.


### License

These sticker is licensed under the Creative Commons Attribution-ShareAlike 4.0 International License.

[![CC-BY-SA4.0](https://i.creativecommons.org/l/by-sa/4.0/88x31.png)](http://creativecommons.org/licenses/by-sa/4.0/)
