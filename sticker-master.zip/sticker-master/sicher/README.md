Sicher
======

These stickers will make your system safe and secure.
They can be applied to any software, hardware, device,
product, institution and even governments.

Your thing is then certified and got 5 out of 5 stars!


#### Print details

These stickers have the format `72mm * 35mm`, in CMYK colors.
Both versions have a `3mm` bleed on each side ("should be cut off").

The uv varnish ("uvlack") version contains a 5th pseudo-color named "lack",
the pink area should be shiny while the rest is dull
(behind the pink it's still green).


#### Wtf?

If you don't know how to druckerei,
ask somebody more competent
and stay the fuck away from this shit.


### License

These stickers are licensed under public domain CC0 "No rights reserved".

[![CC0](http://i.creativecommons.org/p/zero/1.0/88x31.png)](http://creativecommons.org/publicdomain/zero/1.0/)

