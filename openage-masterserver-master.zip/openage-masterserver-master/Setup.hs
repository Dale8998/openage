-- Copyright 2015-2015 the openage authors. See copying.md for legal info.

import Distribution.Simple
main = defaultMain
